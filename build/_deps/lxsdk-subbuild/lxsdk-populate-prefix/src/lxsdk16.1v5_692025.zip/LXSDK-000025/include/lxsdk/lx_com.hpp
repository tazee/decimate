/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_com_HPP
#define LXUSER_com_HPP

#include <lxsdk/lxw_com.hpp>


class CLxUser_GUIDService : public CLxLoc_GUIDService
{
	public:


};
#endif