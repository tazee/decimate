/*
 * LX canvasitem module
 *
 * Copyright 0000
 */
#ifndef LX_canvasitem_H
#define LX_canvasitem_H


	#include <lxsdk/lxcom.h>
	#include <lxsdk/lxvalue.h>




	#define LXsITYPE_CANVAS		"canvas"

#endif