/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_poly_HPP
#define LXUSER_poly_HPP

#include <lxsdk/lxw_poly.hpp>


class CLxUser_Subdivision : public CLxLoc_Subdivision
{
	public:
	CLxUser_Subdivision () {}
	CLxUser_Subdivision (ILxUnknownID obj) : CLxLoc_Subdivision (obj) {}



};
#endif