/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_customview_HPP
#define LXUSER_customview_HPP

#include <lxsdk/lxw_customview.hpp>

#endif