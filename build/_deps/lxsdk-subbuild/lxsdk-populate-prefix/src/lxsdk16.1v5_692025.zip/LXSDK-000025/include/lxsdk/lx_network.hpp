/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_network_HPP
#define LXUSER_network_HPP

#include <lxsdk/lxw_network.hpp>


class CLxUser_NetworkService : public CLxLoc_NetworkService
{
	public:
	/**
	 * Empty Network Service user classes.
	 */
	

};
#endif