/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_viewportframe_HPP
#define LXUSER_viewportframe_HPP

#include <lxsdk/lxw_viewportframe.hpp>

#endif