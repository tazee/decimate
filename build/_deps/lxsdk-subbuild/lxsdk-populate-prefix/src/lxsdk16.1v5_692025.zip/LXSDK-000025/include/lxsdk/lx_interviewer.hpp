/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_interviewer_HPP
#define LXUSER_interviewer_HPP

#include <lxsdk/lxw_interviewer.hpp>

#endif