/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_canvasitem_HPP
#define LXUSER_canvasitem_HPP

#include <lxsdk/lxw_canvasitem.hpp>

#endif