/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_formsys_HPP
#define LXUSER_formsys_HPP

#include <lxsdk/lxw_formsys.hpp>

#endif