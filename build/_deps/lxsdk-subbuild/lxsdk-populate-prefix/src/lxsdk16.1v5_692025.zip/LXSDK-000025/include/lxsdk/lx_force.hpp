/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_force_HPP
#define LXUSER_force_HPP

#include <lxsdk/lxw_force.hpp>


class CLxUser_Force : public CLxLoc_Force
{
	public:
	CLxUser_Force () {}
	CLxUser_Force (ILxUnknownID obj) : CLxLoc_Force (obj) {}



};
#endif