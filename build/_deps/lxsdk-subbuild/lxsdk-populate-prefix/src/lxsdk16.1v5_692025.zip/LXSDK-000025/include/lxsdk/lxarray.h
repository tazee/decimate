/*
 * LX array module
 *
 * Copyright 0000
 */
#ifndef LX_array_H
#define LX_array_H




	#define LXsTYPE_ARRAY "+array"

#endif