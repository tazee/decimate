/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_valuehud_HPP
#define LXUSER_valuehud_HPP

#include <lxsdk/lxw_valuehud.hpp>

#endif