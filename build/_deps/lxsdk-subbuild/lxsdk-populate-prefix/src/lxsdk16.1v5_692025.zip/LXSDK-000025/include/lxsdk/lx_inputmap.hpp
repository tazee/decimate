/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_inputmap_HPP
#define LXUSER_inputmap_HPP

#include <lxsdk/lxw_inputmap.hpp>


class CLxUser_InputMapService : public CLxLoc_InputMapService
{
	public:
	/**
	 * These are only needed to trigger the macros until there are some real ones
	 * elsewhere.
	 */
	

};
#endif