/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_pattern_HPP
#define LXUSER_pattern_HPP

#include <lxsdk/lxw_pattern.hpp>


class CLxUser_Pattern : public CLxLoc_Pattern
{
	public:
	CLxUser_Pattern () {}
	CLxUser_Pattern (ILxUnknownID obj) : CLxLoc_Pattern (obj) {}



};
#endif