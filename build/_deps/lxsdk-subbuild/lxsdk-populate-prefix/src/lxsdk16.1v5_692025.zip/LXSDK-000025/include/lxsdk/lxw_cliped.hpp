/*
 * C++ wrapper for lxcliped.h
 *
 *	Copyright 0000
 *
 */
#ifndef LXW_CLIPED_HPP
#define LXW_CLIPED_HPP

#include <lxsdk/lxcliped.h>
#include <lxsdk/lx_wrap.hpp>
#include <string>

namespace lx {
    static const LXtGUID guid_ClipDest = {0x7d40b3b8,0xc5a4,0x4918,0xb8,0xe4,0x92,0x2e,0x62,0x9c,0x3f,0xfc};
};

class CLxImpl_ClipDest {
  public:
    virtual ~CLxImpl_ClipDest() {}
    virtual LxResult
      locd_Item (void **ppvObj)
        { return LXe_NOTIMPL; }
    virtual int
      locd_Type (void)
        = 0;
    virtual int
      locd_Location (void)
        = 0;
};
#define LXxD_ClipDest_Item LxResult locd_Item (void **ppvObj)
#define LXxO_ClipDest_Item LXxD_ClipDest_Item LXx_OVERRIDE
#define LXxC_ClipDest_Item(c) LxResult c::locd_Item (void **ppvObj)
#define LXxD_ClipDest_Type int locd_Type (void)
#define LXxO_ClipDest_Type LXxD_ClipDest_Type LXx_OVERRIDE
#define LXxC_ClipDest_Type(c) int c::locd_Type (void)
#define LXxD_ClipDest_Location int locd_Location (void)
#define LXxO_ClipDest_Location LXxD_ClipDest_Location LXx_OVERRIDE
#define LXxC_ClipDest_Location(c) int c::locd_Location (void)
template <class T>
class CLxIfc_ClipDest : public CLxInterface
{
    static LxResult
  Item (LXtObjectID wcom, void **ppvObj)
  {
    LXCWxINST (CLxImpl_ClipDest, loc);
    try {
      return loc->locd_Item (ppvObj);
    } catch (LxResult rc) { return rc; }
  }
    static int
  Type (LXtObjectID wcom)
  {
    LXCWxINST (CLxImpl_ClipDest, loc);
    return loc->locd_Type ();
  }
    static int
  Location (LXtObjectID wcom)
  {
    LXCWxINST (CLxImpl_ClipDest, loc);
    return loc->locd_Location ();
  }
  ILxClipDest vt;
public:
  CLxIfc_ClipDest ()
  {
    vt.Item = Item;
    vt.Type = Type;
    vt.Location = Location;
    vTable = &vt.iunk;
    iid = &lx::guid_ClipDest;
  }
};
class CLxLoc_ClipDest : public CLxLocalize<ILxClipDestID>
{
public:
  void _init() {m_loc=0;}
  CLxLoc_ClipDest() {_init();}
  CLxLoc_ClipDest(ILxUnknownID obj) {_init();set(obj);}
  CLxLoc_ClipDest(const CLxLoc_ClipDest &other) {_init();set(other.m_loc);}
  const LXtGUID * guid() const {return &lx::guid_ClipDest;}
    LxResult
  Item (void **ppvObj)
  {
    return m_loc[0]->Item (m_loc,ppvObj);
  }
    CLxResult
  Item (CLxLocalizedObject &o_dest)
  {
    LXtObjectID o_obj;
    LxResult r_c = m_loc[0]->Item(m_loc,&o_obj);
    return lx::TakeResult(o_dest,r_c,o_obj);
  }
    int
  Type (void)
  {
    return m_loc[0]->Type (m_loc);
  }
    int
  Location (void)
  {
    return m_loc[0]->Location (m_loc);
  }
};

#endif
