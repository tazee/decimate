/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_vmath_HPP
#define LXUSER_vmath_HPP

#include <lxsdk/lxw_vmath.hpp>

#endif