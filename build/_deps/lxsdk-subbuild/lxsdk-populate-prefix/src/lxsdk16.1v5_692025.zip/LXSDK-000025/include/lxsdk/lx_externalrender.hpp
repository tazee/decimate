/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_externalrender_HPP
#define LXUSER_externalrender_HPP

#include <lxsdk/lxw_externalrender.hpp>

#endif