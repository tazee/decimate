/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_cliped_HPP
#define LXUSER_cliped_HPP

#include <lxsdk/lxw_cliped.hpp>

#endif