/*
 * LX generic module
 *
 * Copyright 0000
 */
#ifndef LX_generic_H
#define LX_generic_H




	#define LXsTYPE_GENERIC	"+generic"

#endif