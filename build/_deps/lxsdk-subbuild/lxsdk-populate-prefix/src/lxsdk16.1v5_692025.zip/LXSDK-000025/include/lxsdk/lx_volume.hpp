/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_volume_HPP
#define LXUSER_volume_HPP

#include <lxsdk/lxw_volume.hpp>

#endif