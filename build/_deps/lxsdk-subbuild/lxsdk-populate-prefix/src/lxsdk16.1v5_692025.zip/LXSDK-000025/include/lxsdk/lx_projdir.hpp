/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_projdir_HPP
#define LXUSER_projdir_HPP

#include <lxsdk/lxw_projdir.hpp>

#endif