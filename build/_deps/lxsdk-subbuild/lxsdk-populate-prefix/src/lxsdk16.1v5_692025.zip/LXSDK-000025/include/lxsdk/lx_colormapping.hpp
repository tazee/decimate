/*
 * Plug-in SDK Header: C++ User Classes
 *
 * Copyright 0000
 */
#ifndef LXUSER_colormapping_HPP
#define LXUSER_colormapping_HPP

#include <lxsdk/lxw_colormapping.hpp>

	#include <lxsdk/lx_value.hpp>



class CLxUser_ColorMappingService : public CLxLoc_ColorMappingService
{
	public:
	/**
	 * Empty ColorMapping service user classes.
	 */
	

};
#endif