/*
 * Plug-in SDK Source: C++ COM Wrapper Implementation
 *
 * Copyright 0000
 *
 */
#include <lxsdk/lx_plugin.hpp>


	void
initialize (void)
{
}

