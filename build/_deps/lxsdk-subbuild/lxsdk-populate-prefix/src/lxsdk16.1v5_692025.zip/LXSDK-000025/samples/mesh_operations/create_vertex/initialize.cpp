#include "pmodel_createVertex.hpp"

void initialize()
{
    CreateVertex::initialize();
}
